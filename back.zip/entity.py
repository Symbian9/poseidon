# coding: utf-8

# ========================================
# Poseidon 2 Entity Manage Module
# ========================================

from pos.base import *
from pos.setting import *

# Entity Class
class Entity:
    _entityIFF = 0
    _entityName = ''
    _entityOwner = ''
    _entityType = ''
    _groundID = 0
    _flightData = None

    # Entity Join
    def __init__(self, entityIFF, entityName, entityOwner):
        self._entityIFF = entityIFF
        self._entityName = entityName
        if self._entityName in Setting().shipList:
            self._groundID = Setting().shipList[self._entityName].get()
            if self._groundID:
                self._entityType = 'ground'
        else:
            self._entityType = 'aircraft'

    # Entity Unjoin
    def __del__(self):
        print('deleted')
        if self._groundID:
            tmp = self._groundID
            Setting().shipList[self._entityName].add(tmp)
            self._groundID = 0

    # Getting IFF
    def getIFF(self):
        return self._entityIFF

    # Getting Name
    def getName(self):
        return self._entityName

    # Getting Owner
    def getOwner(self):
        return self._entityOwner

    # Getting Type
    def getType(self):
        return self._entityType

    # Getting Ground ID
    def getGroundID(self):
        return self._groundID

    # Getting Flight Data
    def getFlightData(self):
        return self._flightData

    # Setting Flight Data
    def setFlightData(self, flightData):
        self._flightData = flightData

# Entity Manager Class
class EntityManager(Base, Singleton):
    _entityStack = {}

    # Getting Element
    def get(self, entityID):
        return self._entityStack[entityID]

    # Adding Element
    def add(self, entityID, entityObject):
        self._entityStack[entityID] = entityObject

    # Deleting Element
    def delete(self, entityID):
        del self._entityStack[entityID]

    # Getting Elements
    def getList(self):
        return self._entityStack.items()
