# coding: utf-8

# ========================================
# Poseidon 2 Ship Module
# ========================================

from pos.base import *
from pos.setting import *

# Ship Class
class Ship(Base):
    _shipList = []

    # Getting ID
    def get(self):
        if len(self._shipList):
            return self._shipList.pop()
        else:
            return 0

    # Adding ID
    def add(self, shipID):
        if not shipID in self._shipList:
            self._shipList.append(shipID)
