# coding: utf-8

# ========================================
# Poseidon 2 Core Module
# ========================================

import sys
import socket
import threading

from pos.base import *
from pos.setting import *
from pos.thread import *
from pos.user import *
from pos.entity import *

# Main Routine and User Management Class
class Core(Base):
    _setting = None
    _userManager = None
    _entityManager = None
    _listenerObject = None
    _listenerThread = None

    # Start Listening
    def __init__(self):
        # Message
        print('========================================')
        print('   ___               _     _               ____')
        print('  / _ \\___  ___  ___(_) __| | ___  _ __   |___ \\')
        print(' / /_)/ _ \\/ __|/ _ \\ |/ _` |/ _ \\| \'_ \\    __) |')
        print('/ ___/ (_) \\__ \\  __/ | (_| | (_) | | | |  / __/')
        print('\\/    \\___/|___/\\___|_|\\__,_|\\___/|_| |_| |_____|')
        print('========================================')
        print('Poseidon 2 Ver. {}'.format(Setting().currentVersion))
        print('========================================')
        try:
            self._setting = Setting()
            self._userManager = UserManager()
            self._entityManager = EntityManager()
            self._listenerObject = ListenerThread(Setting().proxyAddress, ClientThread)
            self._listenerThread = threading.Thread(target = self._listenerObject.serve_forever)
            self._listenerThread.daemon = True
            self._listenerThread.start()
        except:
            self._message('Cannot start listening .')
        self._message('Listening started.')

    # Main Loop
    def run(self):
        while self.isRunning:
            # Little Shell
            command = input('{} $ '.format(socket.gethostname()))
            if command == '':
                pass
            elif command == 'help':
                self._message('If you want to exit. Type exit.')
            elif command == 'userlist':
                for key, var in UserManager().getList():
                    self._message('[User]{}[ID]{}'.format(key, var.getEntityID()))
            elif command == 'exit':
                self.stop()
                sys.exit()
            else:
                self._message('Command not found.')

    # Messaging
    def _message(self, message):
        print('Poseidon: {}'.format(message))
