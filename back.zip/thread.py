# coding: utf-8

# ========================================
# Poseidon 2 Thread Module
# ========================================

import socket
import threading
import socketserver

from pos.base import *
from pos.setting import *
from pos.packet import *
from pos.user import *

# Listener Thread
class ListenerThread(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass

# Connect to Client Thread
class ClientThread(socketserver.BaseRequestHandler, Base):
    _clientSocket = None
    _serverSocket = None
    _serverThread = None
    _userName = ''
    _packetStacker = None

    # Client Setting
    def setup(self):
        # Define
        self._clientSocket = self.request
        self._serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Launch Packet Stack
        self._packetStacker = PacketStacker(self._clientSocket, self._serverSocket)
        # Connect to Server
        self._serverSocket.connect(Setting().serverAddress)
        self._serverThread = ServerThread(self._serverSocket, self._clientSocket)
        self._serverThread.daemon = True
        self._serverThread.start()
        else:
            # Something Occured
            self.stop()

    # Client Main Routine
    def handle(self):
        while self.isRunning() and self._packetStacker.isRunning():
            self._packetStacker.recieve()
            self._packetStacker.send()

    # Close Process
    def finish(self):
        self._serverSocket.close()
        self._clientSocket.close()
        self._message('Client connection closed')

# Connect to Server Thread
class ServerThread(threading.Thread, Base):
    _serverSocket = None
    _clientSocket = None
    _packetStacker = None

    # Server Setting
    def __init__(self, serverSocket, clientSocket):
        super(ServerThread, self).__init__()
        self._serverSocket = serverSocket
        self._clientSocket = clientSocket
        # Launch Packet Stack
        self._packetStacker = PacketStacker(self._serverSocket, self._clientSocket)

    # Server Main Routine
    def run(self):
        while self.isRunning() and self._packetStacker.isRunning():
            self._packetStacker.recieve()
            self._packetStacker.send()
        self._message('Server connection closed')
