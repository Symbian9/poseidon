# coding: utf-8

# ========================================
# Poseidon 2 User Manage Module
# ========================================

from pos.base import *
from pos.setting import *
from pos.entity import *

# User Class
class User:
    _userName = ''
    _entityObject = None
    _entityID = 0

    # Server Setting
    def __init__(self, userName):
        self._userName = userName

    # Destract Entity
    def __del__(self):
        if self._entityID:
            EntityManager().delete(self._entityID)

    #　Getting Entity
    def getEntity(self):
        return self._entityObject

    #　Setting Entity
    def setEntity(self, entityIFF, entityName):
        self._entityObject = Entity(entityIFF, entityName, self._userName)

    # Adding Entity
    def addEntity(self, entityID):
        self._entityID = entityID
        EntityManager().add(self._entityID, self._entityObject)

    # Deleting Entity
    def delEntity(self):
        EntityManager().delete(self._entityID)

    # Getting Entity ID
    def getEntityID(self):
        return self._entityID

# User Manager Class
class UserManager(Base, Singleton):
    _userStack = {}

    # Getting Element
    def get(self, userName):
        return self._userStack[userName]

    # Adding Element
    def add(self, userName):
        self._userStack[userName] = User(userName)

    # Deleting Element
    def delete(self, userName):
        del self._userStack[userName]

    # Getting Elements
    def getList(self):
        return self._userStack.items()

